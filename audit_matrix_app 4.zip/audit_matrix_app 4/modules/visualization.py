import streamlit as st
import pandas as pd
import plotly.express as px

def display_dashboard(df, audit_results, kpi_df, risk_df):
    df["Audit Result"] = audit_results
    st.subheader("🧾 Bảng kiểm toán")
    st.dataframe(df.style.applymap(lambda v: "background-color: #ffcccc" if "🚫" in str(v) or "🔥" in str(v) else ""))
    st.subheader("📈 Tình trạng tuân thủ tổng thể")
    pie_data = df["Audit Result"].value_counts().reset_index()
    pie_data.columns = ["Status", "Count"]
    fig = px.pie(pie_data, names="Status", values="Count", title="Tình trạng kiểm toán")
    st.plotly_chart(fig, use_container_width=True)
    st.subheader("🔥 Heatmap rủi ro")
    heatmap_data = risk_df.groupby(["Risk Category", "Risk Score"]).size().reset_index(name="Count")
    fig_heatmap = px.density_heatmap(heatmap_data, x="Risk Category", y="Risk Score", z="Count", title="Rủi ro theo danh mục")
    st.plotly_chart(fig_heatmap, use_container_width=True)
    st.subheader("📊 Xu hướng KPI")
    kpi_trend = kpi_df.melt(id_vars=["KPI ID", "Metric"], value_vars=["Mar-2025", "Apr-2025", "May-2025", "Jun-2025"], var_name="Month", value_name="Actual")
    fig_trend = px.line(kpi_trend, x="Month", y="Actual", color="KPI ID", title="Xu hướng KPI")
    st.plotly_chart(fig_trend, use_container_width=True)
