import pandas as pd

def load_matrix(file_path):
    df = pd.read_excel(file_path, sheet_name="ISO42001_Mapping")
    df.fillna("", inplace=True)
    return df

def load_all_sheets(file_path):
    sheets = pd.read_excel(file_path, sheet_name=None)
    return {k: v.fillna("") for k, v in sheets.items()}
